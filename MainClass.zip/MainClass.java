package myproject.atm;
// Create a template
import java.util.Scanner;
public class MainClass {
	public static void main(String[] args) {
		ATMOperationImpl op=new ATMOperationImpl();
		int atmnumber=637892;
		int atmpin=8668;
		//Get the input from user
		Scanner sc=new Scanner(System.in);
		System.out.println("****** WELCOME TO MY ATM MACHINE******");
		System.out.println("Enter ATM Number : ");
		int Number=sc.nextInt();
		System.out.println("Enter ATM pin : ");
		int Pin=sc.nextInt();
		//validate the user input same as the configure
		if((atmnumber==Number)&&(atmpin==Pin)) {
			while(true) {
		    	  System.out.println("-----MENU-----");
		    	  System.out.println("1. View Available Balance\n2.Withdraw Amount\n3.Deposit Amount\n4.View MiniStatement\n5.Exit");
		    	 // ask the user enter the choice
		           System.out.println("Enter Choice :");
		           int ch=sc.nextInt();
		           if(ch==1) {
		        	   op.viewBalance();
		        	   break;
		        	   
		           }else if(ch==2){
		        	   System.out.println("Enter Amount Withdrawn");
		        	   double withdrawAmount=sc.nextDouble();
		        	   op.withdrawAmount(withdrawAmount);
		        	   //break;
		           }
		           else if(ch==3) {
		        	   System.out.println("Enter Amount to Deposit : ");
		        	   double depositAmount=sc.nextDouble();
		        	   op.depositAmount(depositAmount);
		        	  }
		           else if(ch==4) {
		        	   op.viewMiniStatement();
		        	   //break;
		        		  
		           }
		           else if(ch==5) {
		        	   System.out.println("Coollect your ATM card\n ***** Thankyou For using MyATM Machine *****");
		        	  System.exit(0);
		         }
		        else  {
			System.out.println("Please enter valid Choice TryAgain");
		}
			} 
		}
	          else {
		    	  System.out.println("Please enter valid ATM number");
		    	  System.exit(0);
		}
			
	}
}
		
	
